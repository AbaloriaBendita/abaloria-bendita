from pathlib import Path
import json, shutil, re

ROOT = Path('.').resolve()
IMPORT = ROOT / '.catalog-import'
IMG = IMPORT / 'final_assets'


def write_json(path, obj):
    path = ROOT / path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def product(es_id, es_title, price, state='disponible', note='Disponible.', variations=False, en_title=None, en_note=None):
    es = {
        'id': es_id,
        'titulo': es_title,
        'precio': price,
        'estado': state,
        'nota_disponibilidad': note,
    }
    if variations:
        es['permite_variaciones'] = True
    en = {
        'id': es_id,
        'titulo': en_title or es_title,
        'precio': price,
        'estado': state,
        'nota_disponibilidad': en_note or ('Available.' if state == 'disponible' else 'Available to order.'),
    }
    if variations:
        en['permite_variaciones'] = True
    return es, en

# ---------- New products ----------
products = {
    '55': [
        product('55-24','Piedras semipreciosas, semillas, nácar y cristal africano',58,'disponible','Unidades limitadas.',False,'Semi-precious stones, seeds, mother-of-pearl and African glass','Limited units.'),
        product('55-25','Piedras semipreciosas, cristal, madera y resina',58,'disponible','Disponible.',False,'Semi-precious stones, glass, wood and resin','Available.'),
        product('55-26','Ágata natural, piedras semipreciosas, semillas, cristal y latón',62,'disponible','Unidades limitadas.',False,'Natural agate, semi-precious stones, seeds, glass and brass','Limited units.'),
        product('55-27','Piedra natural, cristal y latón',62,'disponible','Unidades limitadas.',False,'Natural stone, glass and brass','Limited units.'),
        product('55-28','Resina italiana · Variaciones de color',68,'variaciones','Posibilidad de cambios de color por petición.',True,'Italian resin · Color variations','Color changes available on request.'),
        product('55-29','Hueso, resina y maderas lacadas',64,'variaciones','Tres modelos disponibles. Elige tu combinación.',True,'Bone, resin and lacquered woods','Three models available. Choose your combination.'),
        product('55-30','Cerámica, cuerda y cuero vegano',72,'variaciones','Tres modelos disponibles.',True,'Ceramic, cord and vegan leather','Three models available.'),
        product('55-31','Cerámica hecha a mano',68,'variaciones','Dos modelos disponibles. Unidades limitadas.',True,'Handmade ceramic','Two models available. Limited units.'),
        product('55-32','Hueso, madera lacada, cristal africano, piedras semipreciosas y cerámica',56,'disponible','Solo 2 unidades.',False,'Bone, lacquered wood, African glass, semi-precious stones and ceramic','Only 2 units.'),
        product('55-33','Ágatas naturales',62,'variaciones','Dos modelos. Piezas únicas.',True,'Natural agates','Two models. Unique pieces.'),
        product('55-34','Caurí natural, caracola natural y cerámica',74,'variaciones','Cuatro modelos. Piezas únicas.',True,'Natural cowrie, natural shell and ceramic','Four models. Unique pieces.'),
    ],
    '79': [
        product('79-54','Cristal africano, cerámica, madera, resina y semillas lacadas',88,'disponible','Unidades limitadas.',False,'African glass, ceramic, wood, resin and lacquered seeds','Limited units.'),
        product('79-55','Cerámica, cristal, madera lacada y resina italiana',82,'disponible','Unidades limitadas.',False,'Ceramic, glass, lacquered wood and Italian resin','Limited units.'),
        product('79-56','Arcilla polimérica',84,'variaciones','Solo por encargo.',True,'Polymer clay','Made to order only.'),
        product('79-57','Collar con caracola · Variaciones',89,'variaciones','Solo por encargo.',True,'Shell necklace · Variations','Made to order only.'),
        product('79-58','Hueso, madera lacada, cristal africano, piedras semipreciosas y cerámica',84,'disponible','Piezas limitadas y todas únicas.',False,'Bone, lacquered wood, African glass, semi-precious stones and ceramic','Limited pieces, each one unique.'),
        product('79-59','Collar largo multicolor',89,'disponible','Disponible.',False,'Long multicolor necklace','Available.'),
    ],
    '99': [
        product('99-24','Madera y resina',99,'variaciones','Solo por encargo.',True,'Wood and resin','Made to order only.'),
    ],
    'especiales': [
        product('especiales-18','Ágatas naturales, madera y silicona',120,'disponible','Disponible.',False,'Natural agates, wood and silicone','Available.'),
        product('especiales-19','Collares combinados',216,'variaciones','Conjunto de 4 collares: 216 € (10% de descuento). Por separado: 58 €, 58 €, 62 € y 62 €. Posibilidad de distintas combinaciones.',True,'Layered necklace combinations','Set of 4 necklaces: €216 (10% discount). Separately: €58, €58, €62 and €62. Different combinations available.'),
    ],
    'pendientes-broches-anillos': [
        product('anillos-01','Anillo de asta natural y cristal nacarado · Ovalado',45,'variaciones','Disponible en distintos colores.',True,'Natural horn and pearly glass ring · Oval','Available in different colors.'),
        product('anillos-02','Anillos de asta natural y cristal nacarado · Redondo y ovalado','40–45','variaciones','Modelo redondo 40 €. Modelo ovalado 45 €. Consulta colores disponibles.',True,'Natural horn and pearly glass rings · Round and oval','Round model €40. Oval model €45. Ask about available colors.'),
        product('anillos-03','Anillos cuadrados de cristal nacarado y asta natural',35,'variaciones','Varios colores y pequeños motivos. Consulta disponibilidad.',True,'Square pearly glass and natural horn rings','Several colors and small motifs. Ask about availability.'),
        product('anillos-04','Anillo floral',99,'disponible','Disponible.',False,'Floral ring','Available.'),
    ]
}

# Write new data files
for slug, items in products.items():
    for es, en in items:
        pid = es['id']
        write_json(f'assets/colecciones/{slug}/{pid}/data.json', es)
        write_json(f'en/assets/{slug}/{pid}/data.json', en)

# Copy new images into their final product folders
image_mapping = {
    '55': [f'55-{i:02d}' for i in range(24,35)],
    '79': [f'79-{i:02d}' for i in range(54,60)],
    '99': ['99-24'],
    'especiales': ['especiales-18','especiales-19'],
    'pendientes-broches-anillos': ['anillos-01','anillos-02','anillos-03','anillos-04'],
}
for slug, ids in image_mapping.items():
    for pid in ids:
        src_dir = IMG / pid
        dst_dir = ROOT / 'assets' / 'colecciones' / slug / pid
        dst_dir.mkdir(parents=True, exist_ok=True)
        for name in ('main.jpg','hover.jpg'):
            src = src_dir / name
            if src.exists():
                shutil.copy2(src, dst_dir / name)

# ---------- Unified earrings / brooches / rings collection ----------
unified = ROOT / 'assets' / 'colecciones' / 'pendientes-broches-anillos'
unified.mkdir(parents=True, exist_ok=True)
unified_en = ROOT / 'en' / 'assets' / 'pendientes-broches-anillos'
unified_en.mkdir(parents=True, exist_ok=True)

# Copy current earrings and brooches into new collection without changing product IDs
for src_slug, ids in {
    'pendientes': ['pendientes-01','pendientes-02','pendientes-03'],
    'broches': ['broches-01','broches-02','broches-03','broches-04','broches-05'],
}.items():
    for pid in ids:
        src = ROOT / 'assets' / 'colecciones' / src_slug / pid
        dst = unified / pid
        if dst.exists(): shutil.rmtree(dst)
        shutil.copytree(src, dst)
        src_en = ROOT / 'en' / 'assets' / src_slug / pid / 'data.json'
        dst_en = unified_en / pid
        dst_en.mkdir(parents=True, exist_ok=True)
        if src_en.exists(): shutil.copy2(src_en, dst_en / 'data.json')

# Move existing ring 55-23 into the unified visible collection while preserving original files
pid='55-23'
src = ROOT / 'assets' / 'colecciones' / '55' / pid
if src.exists():
    dst = unified / pid
    if dst.exists(): shutil.rmtree(dst)
    shutil.copytree(src, dst)
    src_en = ROOT / 'en' / 'assets' / '55' / pid / 'data.json'
    dst_en = unified_en / pid
    dst_en.mkdir(parents=True, exist_ok=True)
    if src_en.exists(): shutil.copy2(src_en, dst_en / 'data.json')

unified_ids = ['pendientes-01','pendientes-02','pendientes-03','broches-01','broches-02','broches-03','broches-04','broches-05','55-23','anillos-01','anillos-02','anillos-03','anillos-04']
write_json('assets/colecciones/pendientes-broches-anillos/index.json', unified_ids)

# ---------- Collection indices ----------
idx55 = json.loads((ROOT/'assets/colecciones/55/index.json').read_text(encoding='utf-8'))
idx55 = [x for x in idx55 if x != '55-23' and not (x.startswith('55-') and x in [f'55-{i:02d}' for i in range(24,35)])]
idx55 += [f'55-{i:02d}' for i in range(24,35)]
write_json('assets/colecciones/55/index.json', idx55)

for slug, new_ids in {
    '79':[f'79-{i:02d}' for i in range(54,60)],
    '99':['99-24'],
    'especiales':['especiales-18','especiales-19'],
}.items():
    p=ROOT/f'assets/colecciones/{slug}/index.json'
    idx=json.loads(p.read_text(encoding='utf-8'))
    idx=[x for x in idx if x not in new_ids] + new_ids
    write_json(f'assets/colecciones/{slug}/index.json', idx)

# ---------- New collection pages, preserving current layout ----------
def build_es_page():
    src=(ROOT/'colecciones/pendientes/index.html').read_text(encoding='utf-8')
    repl={
        'Pendientes · Abaloria Bendita':'Pendientes, broches y anillos · Abaloria Bendita',
        'Pendientes únicos hechos a mano. Colección Pendientes con gracia desde 39 €. Piezas irrepetibles.':'Pendientes, broches y anillos únicos hechos a mano. Piezas irrepetibles desde 34 €.',
        'https://abaloriabendita.es/colecciones/55/':'https://abaloriabendita.es/colecciones/pendientes-broches-anillos/',
        'Pendientes únicos hechos a mano desde 39 €.':'Pendientes, broches y anillos únicos hechos a mano desde 34 €.',
        'https://abaloriabendita.es/colecciones/pendientes/':'https://abaloriabendita.es/colecciones/pendientes-broches-anillos/',
        'https://abaloriabendita.es/colecciones/pendientes/cover.jpg':'https://abaloriabendita.es/colecciones/pendientes-broches-anillos/cover.jpg',
        '"name": "Sencilla con gracia"':'"name": "Pendientes, broches y anillos"',
        '<body data-collection="pendientes">':'<body data-collection="pendientes-broches-anillos">',
        "collection: 'pendientes'":"collection: 'pendientes-broches-anillos'",
        "price_range: '35'":"price_range: '34+'",
        '<h1>Pendientes<span class="c-yellow">.</span></h1>':'<h1>Pendientes, broches y anillos<span class="c-yellow">.</span></h1>',
        'Pendientes únicos hechos a mano. La colección de pendientes artesanales con personalidad y mucho amor<br>':'Pendientes, broches y anillos únicos hechos a mano. Piezas artesanales con personalidad y mucho amor.<br>',
    }
    for a,b in repl.items(): src=src.replace(a,b)
    return src

def build_en_page():
    src=(ROOT/'en/collections/pendientes/index.html').read_text(encoding='utf-8')
    replacements=[
        ('Earrings · Abaloria Bendita','Earrings, brooches & rings · Abaloria Bendita'),
        ('Unique handmade earrings','Unique handmade earrings, brooches and rings'),
        ('/en/collections/pendientes/','/en/collections/pendientes-broches-anillos/'),
        ('/colecciones/pendientes/cover.jpg','/colecciones/pendientes-broches-anillos/cover.jpg'),
        ('data-collection="pendientes"','data-collection="pendientes-broches-anillos"'),
        ("collection: 'pendientes'","collection: 'pendientes-broches-anillos'"),
        ("price_range: '35'","price_range: '34+'"),
        ('<h1>Earrings<span class="c-yellow">.</span></h1>','<h1>Earrings, brooches & rings<span class="c-yellow">.</span></h1>'),
    ]
    for a,b in replacements: src=src.replace(a,b)
    # If page prose uses a different exact sentence, normalize only the intro paragraph content
    src=re.sub(r'(class="available-intro">\s*<h1>.*?</h1>\s*<p>)(.*?)(</p>)', r'\1\n      Unique handmade earrings, brooches and rings. Artisan pieces full of personality and love.<br>\n    \3', src, flags=re.S)
    return src

es_page=build_es_page()
en_page=build_en_page()
(ROOT/'colecciones/pendientes-broches-anillos').mkdir(parents=True, exist_ok=True)
(ROOT/'colecciones/pendientes-broches-anillos/index.html').write_text(es_page,encoding='utf-8')
(ROOT/'en/collections/pendientes-broches-anillos').mkdir(parents=True, exist_ok=True)
(ROOT/'en/collections/pendientes-broches-anillos/index.html').write_text(en_page,encoding='utf-8')

# Cover: keep current visual language by reusing earrings cover
shutil.copy2(ROOT/'colecciones/pendientes/cover.jpg', ROOT/'colecciones/pendientes-broches-anillos/cover.jpg')

# ---------- Home: 6 -> 5 cards, keeping the exact card markup/classes ----------
def replace_home_es(text):
    text=text.replace('También broches y pendientes.','También pendientes, broches y anillos.')
    start=text.index('    <!-- Pendientes -->')
    end=text.index('    <!-- Colecciones especiales -->') if '    <!-- Colecciones especiales -->' in text else text.index('    <!-- Especiales -->')
    card='''    <!-- Pendientes, broches y anillos -->\n    <article class="collection-card">\n  <a href="/colecciones/pendientes-broches-anillos/">\n\n    <div class="collection-body">\n      <h3>Pendientes, broches y anillos.</h3>\n    </div>\n\n    <div class="collection-media">\n      <img src="/colecciones/pendientes-broches-anillos/cover.jpg" alt="Pendientes, broches y anillos">\n    </div>\n\n    <div class="collection-footer">\n  <span class="collection-price-text">Desde 34 €</span>\n  <span class="collection-cta">Ver la colección</span>\n</div>\n\n  </a>\n</article>\n\n\n'''
    return text[:start]+card+text[end:]

def replace_home_en(text):
    text=text.replace('Earrings and brooches also available.','Earrings, brooches and rings also available.')
    # current text sometimes line-breaks the sentence; handle second form
    text=text.replace('Earrings and brooches also available.','Earrings, brooches and rings also available.')
    start=text.index('    <article class="collection-card">\n      <a href="/en/collections/pendientes/">')
    # locate special collections card after brooches
    end=text.index('    <article class="collection-card">\n      <a href="/en/collections/especiales/">', start)
    card='''    <article class="collection-card">\n      <a href="/en/collections/pendientes-broches-anillos/">\n        <div class="collection-body">\n          <h3>Earrings, brooches &amp; rings.</h3>\n        </div>\n        <div class="collection-media">\n          <img src="/colecciones/pendientes-broches-anillos/cover.jpg" alt="Earrings, brooches and rings">\n        </div>\n        <div class="collection-footer">\n          <span class="collection-price-text">From €34</span>\n          <span class="collection-cta">View collection</span>\n        </div>\n      </a>\n    </article>\n\n'''
    return text[:start]+card+text[end:]

p=ROOT/'index.html'; p.write_text(replace_home_es(p.read_text(encoding='utf-8')),encoding='utf-8')
p=ROOT/'en/index.html'; p.write_text(replace_home_en(p.read_text(encoding='utf-8')),encoding='utf-8')

# ---------- Sitemap ----------
smap=ROOT/'sitemap.xml'
s=smap.read_text(encoding='utf-8')
# Remove separate ES brooches/pendientes URL blocks
s=re.sub(r'\n  <url>\s*<loc>https://abaloriabendita\.es/colecciones/(?:broches|pendientes)/</loc>.*?</url>\n', '\n', s, flags=re.S)
insert='''\n  <url>\n    <loc>https://abaloriabendita.es/colecciones/pendientes-broches-anillos/</loc>\n    <lastmod>2026-09-19</lastmod>\n    <priority>0.8</priority>\n  </url>\n'''
pos=s.index('  <!-- HOME EN -->')
s=s[:pos]+insert+'\n'+s[pos:]
# add EN unified before urlset close if not present
if 'en/collections/pendientes-broches-anillos/' not in s:
    s=s.replace('\n</urlset>', '''\n  <url>\n    <loc>https://abaloriabendita.es/en/collections/pendientes-broches-anillos/</loc>\n    <lastmod>2026-09-19</lastmod>\n    <priority>0.6</priority>\n  </url>\n\n</urlset>''')
smap.write_text(s,encoding='utf-8')

# ---------- Legacy collection pages: redirect old URLs ----------
def redirect_page(lang, target, title):
    return f'''<!doctype html>\n<html lang="{lang}">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1">\n<meta http-equiv="refresh" content="0; url={target}">\n<link rel="canonical" href="https://abaloriabendita.es{target}">\n<meta name="robots" content="noindex, follow">\n<title>{title} · Abaloria Bendita</title>\n<script>location.replace({json.dumps(target)});</script>\n</head>\n<body><p><a href="{target}">{'Ir a la colección' if lang=='es' else 'Go to collection'}</a></p></body>\n</html>\n'''
for name in ('pendientes','broches'):
    (ROOT/f'colecciones/{name}/index.html').write_text(redirect_page('es','/colecciones/pendientes-broches-anillos/','Pendientes, broches y anillos'),encoding='utf-8')
    en_old=ROOT/f'en/collections/{name}/index.html'
    if en_old.exists():
        en_old.write_text(redirect_page('en','/en/collections/pendientes-broches-anillos/','Earrings, brooches & rings'),encoding='utf-8')

# ---------- Validation ----------
for p in ROOT.glob('assets/colecciones/*/index.json'):
    json.loads(p.read_text(encoding='utf-8'))
for slug, items in image_mapping.items():
    for pid in items:
        main=ROOT/'assets/colecciones'/slug/pid/'main.jpg'
        if not main.exists(): raise SystemExit(f'Missing image: {main}')
print('Catalog update applied successfully')
